from flask import Flask, render_template, request
import csv
import os
from datetime import datetime, timedelta
from collections import defaultdict

app = Flask(__name__)
DATA_FILE = os.path.join(os.path.dirname(__file__), "data", "sales.csv")

def load_sales():
    records = []
    with open(DATA_FILE, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            records.append({
                "date": datetime.strptime(row["date"], "%Y-%m-%d").date(),
                "product": row["product"],
                "units_sold": int(row["units_sold"]),
                "stock_on_hand": int(row["stock_on_hand"])
            })
    return records

def forecast_product(records, product):
    rows = sorted([r for r in records if r["product"] == product], key=lambda r: r["date"])
    if not rows:
        return None

    # Simple transparent baseline forecast: average daily sales over the latest 7 records.
    # This can later be replaced with a trained ML model when more real data is available.
    recent = rows[-7:]
    avg_daily_demand = sum(r["units_sold"] for r in recent) / len(recent)
    current_stock = rows[-1]["stock_on_hand"]
    days_left = current_stock / avg_daily_demand if avg_daily_demand > 0 else None
    reorder_point = max(1, round(avg_daily_demand * 3))  # 3 days of demand as safety stock
    risk = "HIGH" if current_stock <= reorder_point or (days_left is not None and days_left <= 3) else (
        "MEDIUM" if days_left is not None and days_left <= 7 else "LOW"
    )
    suggested_order = max(0, round(avg_daily_demand * 7 - current_stock))
    return {
        "product": product,
        "current_stock": current_stock,
        "avg_daily_demand": round(avg_daily_demand, 2),
        "days_left": round(days_left, 1) if days_left is not None else None,
        "reorder_point": reorder_point,
        "suggested_order": suggested_order,
        "risk": risk,
        "last_date": rows[-1]["date"].isoformat()
    }

@app.route("/", methods=["GET", "POST"])
def index():
    records = load_sales()
    products = sorted(set(r["product"] for r in records))
    selected = request.form.get("product", products[0] if products else "")
    results = [forecast_product(records, p) for p in products]
    results = [r for r in results if r]
    selected_result = forecast_product(records, selected) if selected else None
    return render_template("index.html", products=products, results=results,
                           selected=selected, selected_result=selected_result)

if __name__ == "__main__":
    app.run(debug=True)
