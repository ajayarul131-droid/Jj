# AI-Based Stock-Out Prediction System

## Features
- Product-wise inventory dashboard
- Recent average daily demand calculation
- Estimated days until stock runs out
- HIGH / MEDIUM / LOW inventory risk classification
- Suggested reorder quantity
- Sample sales and inventory data included

## Requirements
- Python 3.9 or newer
- Internet connection for the first-time Flask installation

## Run on Windows
1. Extract the ZIP file.
2. Open Command Prompt in the extracted project folder.
3. Run: `py -m pip install -r requirements.txt`
4. Run: `py app.py`
5. Open `http://127.0.0.1:5000` in your browser.

## Run on macOS / Linux
1. Open Terminal in the extracted project folder.
2. Run: `python3 -m pip install -r requirements.txt`
3. Run: `python3 app.py`
4. Open `http://127.0.0.1:5000` in your browser.

## Data format
Edit `data/sales.csv`. Keep these columns:
- `date` in YYYY-MM-DD format
- `product`
- `units_sold`
- `stock_on_hand`

Each product should have multiple dated records. The app uses the latest stock figure and average sales from up to the latest 7 records.

## How the estimate works
- Average daily demand = average units sold across the latest 7 records.
- Estimated days left = current stock / average daily demand.
- Reorder point = approximately 3 days of average demand.
- Suggested order = quantity needed to cover approximately 7 days of average demand.

This is a working academic prototype using a simple baseline forecast, not a trained machine-learning model. With more historical data, it can be extended to use regression or time-series forecasting and evaluated against actual demand.
